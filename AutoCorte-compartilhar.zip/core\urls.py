from django.urls import path
from . import views


urlpatterns = [
    path("", views.index, name="index"),
    path("cadastrar-agendamento/", views.cadastrar_agendamento, name="cadastrar_agendamento"),
    path("listar-servicos/", views.listar_servicos, name="listar_servicos"),
    path("excluir-servico/<int:id>/", views.excluir_servico, name="excluir_servico"),
]
